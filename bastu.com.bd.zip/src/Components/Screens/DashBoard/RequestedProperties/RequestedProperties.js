import React from 'react';
import './RequestedProperties.css'

function RequestedProperties() {
  return (
    <div>RequestedProperties</div>
  )
}

export default RequestedProperties