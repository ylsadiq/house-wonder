export const backendUrl = 'http://backend.bastu.techpagol.com/'
export const spacesBucketUrl = 'https://bastu-test.sgp1.digitaloceanspaces.com/'